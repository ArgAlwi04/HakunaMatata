package com.example.pbo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
