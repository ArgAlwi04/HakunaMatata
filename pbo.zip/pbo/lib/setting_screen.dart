import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class PengaturanScreen extends StatelessWidget {
  final List<Map<String, String>> daftarAntrian;
  final Function(int, String, String, String) onEditPemilih;
  final Function(int) onHapusPemilih;

  PengaturanScreen({
    required this.daftarAntrian,
    required this.onEditPemilih,
    required this.onHapusPemilih,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Edit Antrian'),
      ),
      body: ListView.builder(
        itemCount: daftarAntrian.length,
        itemBuilder: (context, index) {
          final pemilih = daftarAntrian[index];
          return Card(
            child: ListTile(
              title: Text(pemilih['Nama'] ?? ''),
              subtitle: Text(
                  'NIK: ${pemilih['NIK']} | Jam: ${pemilih['Jam Dijadwalkan']}'),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: Icon(Icons.edit),
                    onPressed: () {
                      // Panggil fungsi edit untuk mengedit antrian
                      _showEditDialog(context, index);
                    },
                  ),
                  IconButton(
                    icon: Icon(Icons.delete),
                    onPressed: () {
                      // Panggil fungsi hapus untuk menghapus antrian
                      onHapusPemilih(index);
                    },
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // Dialog untuk mengedit antrian
  void _showEditDialog(BuildContext context, int index) {
    final TextEditingController namaController = TextEditingController();
    final TextEditingController nikController = TextEditingController();
    final TextEditingController jamController = TextEditingController();

    // Mengisi controller dengan data yang ada
    namaController.text = daftarAntrian[index]['Nama'] ?? '';
    nikController.text = daftarAntrian[index]['NIK'] ?? '';
    jamController.text = daftarAntrian[index]['Jam Dijadwalkan'] ?? '';

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Edit Antrian'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: namaController,
                decoration: InputDecoration(labelText: 'Nama'),
              ),
              TextField(
                controller: nikController,
                decoration: InputDecoration(labelText: 'NIK'),
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              ),
              TextField(
                controller: jamController,
                readOnly: true,
                onTap: () => _pickTime(context, jamController),
                decoration: InputDecoration(labelText: 'Jam Dijadwalkan'),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                onEditPemilih(
                  index,
                  namaController.text,
                  nikController.text,
                  jamController.text,
                );
                Navigator.pop(context);
              },
              child: Text('Simpan'),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text('Batal'),
            ),
          ],
        );
      },
    );
  }

  // Fungsi untuk memilih jam menggunakan TimePicker
  Future<void> _pickTime(
      BuildContext context, TextEditingController jamController) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
      builder: (context, child) {
        return MediaQuery(
          data: MediaQuery.of(context).copyWith(alwaysUse24HourFormat: true),
          child: child!,
        );
      },
    );

    if (picked != null) {
      final formattedTime = picked.format(context);
      jamController.text = formattedTime;
    }
  }
}
