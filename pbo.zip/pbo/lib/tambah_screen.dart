import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class TambahPemilihScreen extends StatelessWidget {
  final Function(String, String, String) onAddPemilih;

  TambahPemilihScreen({required this.onAddPemilih});

  final TextEditingController namaController = TextEditingController();
  final TextEditingController nikController = TextEditingController();
  final TextEditingController jamController = TextEditingController();

  // Fungsi untuk memilih jam menggunakan TimePicker
  Future<void> _pickTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
      builder: (context, child) {
        return MediaQuery(
          data: MediaQuery.of(context).copyWith(alwaysUse24HourFormat: true),
          child: child!,
        );
      },
    );

    if (picked != null) {
      // Format jam menjadi string 24 jam: HH:mm
      final formattedTime = picked.format(context);
      jamController.text = formattedTime;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tambah Pemilih'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextFormField(
              controller: namaController,
              decoration: InputDecoration(labelText: 'Nama'),
            ),
            TextFormField(
              controller: nikController,
              decoration: InputDecoration(labelText: 'NIK'),
              keyboardType: TextInputType.number, // Menampilkan keyboard angka
              inputFormatters: [
                FilteringTextInputFormatter
                    .digitsOnly, // Membatasi input hanya angka
              ],
            ),
            TextFormField(
              controller: jamController,
              readOnly: true, // Agar user tidak bisa langsung mengedit
              onTap: () =>
                  _pickTime(context), // Buka TimePicker saat field ditekan
              decoration: InputDecoration(labelText: 'Jam Dijadwalkan'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                final nama = namaController.text;
                final nik = nikController.text;
                final jamDijadwalkan = jamController.text;

                if (nama.isNotEmpty &&
                    nik.isNotEmpty &&
                    jamDijadwalkan.isNotEmpty) {
                  onAddPemilih(nama, nik, jamDijadwalkan);
                  Navigator.pop(context);
                }
              },
              child: Text('Simpan'),
            ),
          ],
        ),
      ),
    );
  }
}
