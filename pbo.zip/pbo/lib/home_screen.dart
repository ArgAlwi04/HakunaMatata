import 'package:flutter/material.dart';
import 'package:pbo/tambah_screen.dart';
import 'package:pbo/setting_screen.dart';
import 'package:pbo/login_screen.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Map<String, String>> daftarAntrian = [];
  List<Map<String, String>> riwayatAntrian =
      []; // Untuk menyimpan riwayat antrian

  // Fungsi untuk menambah data ke daftar antrian
  void tambahPemilih(String nama, String nik, String jamDijadwalkan) {
    setState(() {
      daftarAntrian.add({
        'Nama': nama,
        'NIK': nik,
        'Jam Dijadwalkan': jamDijadwalkan,
      });
      riwayatAntrian.add({
        'Nama': nama,
        'NIK': nik,
        'Jam Dijadwalkan': jamDijadwalkan,
        'Status': 'Masuk'
      });
    });
  }

  // Fungsi untuk mengedit antrian
  void editPemilih(int index, String nama, String nik, String jamDijadwalkan) {
    setState(() {
      daftarAntrian[index] = {
        'Nama': nama,
        'NIK': nik,
        'Jam Dijadwalkan': jamDijadwalkan,
      };
    });
  }

  // Fungsi untuk menghapus antrian
  void hapusPemilih(int index) {
    setState(() {
      final removedItem = daftarAntrian[index];
      riwayatAntrian.add({
        'Nama': removedItem['Nama'] ?? '',
        'NIK': removedItem['NIK'] ?? '',
        'Jam Dijadwalkan': removedItem['Jam Dijadwalkan'] ?? '',
        'Status': 'Keluar'
      });
      daftarAntrian.removeAt(index);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Sistem Antrian Pemilu'),
        automaticallyImplyLeading: true, // Membiarkan tombol menu default
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                color: const Color.fromARGB(255, 22, 101, 166),
              ),
              child: Text(
                'Menu',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                ),
              ),
            ),
            ListTile(
              leading: Icon(Icons.account_circle),
              title: Text('Akun'),
              onTap: () {
                // Logika untuk menampilkan informasi akun yang sedang login
                showDialog(
                  context: context,
                  builder: (context) {
                    return AlertDialog(
                      title: Text('Akun'),
                      content: Text(
                          'Admin'), // Ganti dengan nama akun sebenarnya
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: Text('Tutup'),
                        ),
                      ],
                    );
                  },
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.history),
              title: Text('Riwayat'),
              onTap: () {
                // Menampilkan riwayat antrian
                Navigator.pop(context); // Tutup drawer sebelum navigasi
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) =>
                        RiwayatScreen(riwayatAntrian: riwayatAntrian),
                  ),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.logout),
              title: Text('Logout'),
              onTap: () {
                // Mengarahkan ke halaman LoginScreen
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => LoginScreen()),
                );
              },
            ),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => TambahPemilihScreen(
                          onAddPemilih: tambahPemilih,
                        ),
                      ),
                    );
                  },
                  child: Text('Tambah Antrian'),
                ),
                ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => PengaturanScreen(
                          daftarAntrian: daftarAntrian,
                          onEditPemilih: editPemilih,
                          onHapusPemilih: hapusPemilih,
                        ),
                      ),
                    );
                  },
                  child: Text('Edit Antrian'),
                ),
              ],
            ),
            SizedBox(height: 20),
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  border: Border.all(),
                ),
                child: daftarAntrian.isNotEmpty
                    ? ListView.builder(
                        itemCount: daftarAntrian.length,
                        itemBuilder: (context, index) {
                          final pemilih = daftarAntrian[index];
                          return ListTile(
                            title: Text(pemilih['Nama'] ?? ''),
                            subtitle: Text(
                                'NIK: ${pemilih['NIK']} | Jam: ${pemilih['Jam Dijadwalkan']}'),
                          );
                        },
                      )
                    : Center(
                        child: Text('Daftar Antrian Kosong'),
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class RiwayatScreen extends StatelessWidget {
  final List<Map<String, String>> riwayatAntrian;

  RiwayatScreen({required this.riwayatAntrian});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Riwayat Antrian'),
      ),
      body: ListView.builder(
        itemCount: riwayatAntrian.length,
        itemBuilder: (context, index) {
          final riwayat = riwayatAntrian[index];
          return ListTile(
            title: Text(riwayat['Nama'] ?? ''),
            subtitle: Text(
                'NIK: ${riwayat['NIK']} | Jam: ${riwayat['Jam Dijadwalkan']} | Status: ${riwayat['Status']}'),
          );
        },
      ),
    );
  }
}
